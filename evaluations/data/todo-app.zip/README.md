# Todos

A small todo list in the browser, on Python 3's standard library alone.

```bash
python3 app.py                      # http://localhost:8000
python3 app.py --port 9000 --data /tmp/todos.json
```

Todos are kept in `todos.json` beside `app.py`.

- `app.py`: the web server and its JSON API under `/api/todos`
- `storage.py`: reading and writing the todos
- `static/`: the page
