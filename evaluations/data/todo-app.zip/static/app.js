const list = document.querySelector("#todos");
const form = document.querySelector("#new-todo");
const filterButtons = document.querySelectorAll("[data-filter]");
const remaining = document.querySelector("#remaining");

const shown = {
  all: () => true,
  active: (todo) => !todo.completed,
  completed: (todo) => todo.completed,
};

let todos = [];
let filter = "all";

async function request(method, url, body) {
  const response = await fetch(url, {
    method,
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!response.ok) {
    throw new Error(`${method} ${url} failed with ${response.status}`);
  }
  return response.status === 204 ? null : response.json();
}

async function load() {
  todos = await request("GET", "/api/todos");
  render();
}

function render() {
  const visible = todos.filter(shown[filter]);
  list.replaceChildren(...visible.map(item));
  const left = todos.filter(shown.active).length;
  remaining.textContent = `${left} ${left === 1 ? "item" : "items"} left`;
  for (const button of filterButtons) {
    button.classList.toggle("selected", button.dataset.filter === filter);
  }
}

function item(todo, index) {
  const row = document.createElement("li");
  row.classList.toggle("completed", todo.completed);

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.checked = todo.completed;
  checkbox.setAttribute("aria-label", `Complete ${todo.title}`);
  checkbox.addEventListener("change", () => complete(todo.id, checkbox.checked));

  const title = document.createElement("span");
  title.textContent = todo.title;

  const remove = document.createElement("button");
  remove.textContent = "Delete";
  remove.setAttribute("aria-label", `Delete ${todo.title}`);
  remove.addEventListener("click", () => removeAt(index));

  row.append(checkbox, title, remove);
  return row;
}

async function add(title) {
  await request("POST", "/api/todos", { title });
  await load();
}

async function complete(id, completed) {
  await request("PATCH", `/api/todos/${id}`, { completed });
  await load();
}

async function removeAt(index) {
  await request("DELETE", `/api/todos/${todos[index].id}`);
  await load();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const input = form.elements.title;
  await add(input.value);
  input.value = "";
  input.focus();
});

for (const button of filterButtons) {
  button.addEventListener("click", () => {
    filter = button.dataset.filter;
    render();
  });
}

load();
