"""A small todo list in the browser: `python3 app.py`, then open http://localhost:8000."""

import argparse
from contextlib import suppress
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

from storage import TodoStore

ROOT = Path(__file__).resolve().parent
TODOS = "/api/todos"
ONE_TODO = re.compile(r"^/api/todos/(\d+)$")


class Handler(SimpleHTTPRequestHandler):
    """Serves the page from `static/` and the todos as JSON under /api/todos."""

    store: TodoStore

    def do_GET(self) -> None:
        if self._path() == TODOS:
            self._send(HTTPStatus.OK, self.store.todos())
        else:
            super().do_GET()

    def do_POST(self) -> None:
        if self._path() != TODOS:
            self._send(HTTPStatus.NOT_FOUND, {"error": "Not found."})
            return
        try:
            todo = self.store.add(str(self._body().get("title", "")))
        except ValueError as error:
            self._send(HTTPStatus.BAD_REQUEST, {"error": str(error)})
            return
        self._send(HTTPStatus.CREATED, todo)

    def do_PATCH(self) -> None:
        todo_id = self._todo_id()
        completed = self._body().get("completed")
        if todo_id is None or not isinstance(completed, bool):
            self._send(HTTPStatus.BAD_REQUEST, {"error": 'Send {"completed": true or false} to /api/todos/<id>.'})
            return
        todo = self.store.set_completed(todo_id, completed)
        if todo is None:
            self._send(HTTPStatus.NOT_FOUND, {"error": f"No todo {todo_id}."})
        else:
            self._send(HTTPStatus.OK, todo)

    def do_DELETE(self) -> None:
        todo_id = self._todo_id()
        if todo_id is None or not self.store.delete(todo_id):
            self._send(HTTPStatus.NOT_FOUND, {"error": "No such todo."})
            return
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def _path(self) -> str:
        return urlsplit(self.path).path

    def _todo_id(self) -> int | None:
        found = ONE_TODO.match(self._path())
        return int(found.group(1)) if found else None

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            return {}
        return body if isinstance(body, dict) else {}

    def _send(self, status: HTTPStatus, value: object) -> None:
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--data", type=Path, default=ROOT / "todos.json", help="where the todos are kept")
    arguments = parser.parse_args()
    Handler.store = TodoStore(arguments.data)
    server = ThreadingHTTPServer(("", arguments.port), partial(Handler, directory=str(ROOT / "static")))
    print(f"Todos at http://localhost:{arguments.port}", flush=True)
    with suppress(KeyboardInterrupt):
        server.serve_forever()


if __name__ == "__main__":
    main()
