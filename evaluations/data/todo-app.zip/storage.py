"""Todos kept in a JSON file."""

import json
from pathlib import Path
import threading
from typing import TypedDict


class Todo(TypedDict):
    id: int
    title: str
    completed: bool


class TodoStore:
    """The todo list in one JSON file, safe to use from several threads."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()

    def todos(self) -> list[Todo]:
        """Every todo, oldest first."""
        with self._lock:
            return self._read()["todos"]

    def add(self, title: str) -> Todo:
        """Add a todo that is not completed yet."""
        title = title.strip()
        if not title:
            raise ValueError("A todo needs a title.")
        with self._lock:
            data = self._read()
            todo: Todo = {"id": data["next_id"], "title": title, "completed": False}
            data["todos"].append(todo)
            data["next_id"] += 1
            self._write(data)
            return todo

    def set_completed(self, todo_id: int, completed: bool) -> Todo | None:
        """Mark a todo completed or not; None when there is no such todo."""
        with self._lock:
            data = self._read()
            for todo in data["todos"]:
                if todo["id"] == todo_id:
                    todo["completed"] = completed
                    self._write(data)
                    return todo
            return None

    def delete(self, todo_id: int) -> bool:
        """Delete a todo; False when there is no such todo."""
        with self._lock:
            data = self._read()
            kept = [todo for todo in data["todos"] if todo["id"] != todo_id]
            if len(kept) == len(data["todos"]):
                return False
            data["todos"] = kept
            self._write(data)
            return True

    def _read(self) -> dict:
        if not self.path.is_file():
            return {"next_id": 1, "todos": []}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, data: dict) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
        temporary.replace(self.path)
